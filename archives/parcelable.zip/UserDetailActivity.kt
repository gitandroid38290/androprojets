package training.androidkotlin.helloworld

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.TextView

class UserDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_detail)

        val user = intent.getParcelableExtra<User>("user")

        val nameTextView = findViewById(R.id.name) as TextView
        val ageTextView = findViewById(R.id.age) as TextView

        nameTextView.setText("Nom : ${user.name}")
        ageTextView.setText("Age : ${user.age}")
    }
}
