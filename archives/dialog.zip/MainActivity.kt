package training.androidkotlin.helloworld

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById(R.id.show_dialog_button).setOnClickListener {
            val fragment = ConfirmDeleteDialogFragment()
            fragment.listener = object: ConfirmDeleteDialogFragment.ConfirmDeleteListener {
                override fun onDialogPositiveClick() {
                    val fragment = FileListDialogFragment()
                    fragment.show(fragmentManager, "fileListDialogFragment")
                }

                override fun onDialogNegativeClick() { }

            }

            fragment.show(fragmentManager, "confirmDelete")
        }

    }
}
