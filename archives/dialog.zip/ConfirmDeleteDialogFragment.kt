package training.androidkotlin.helloworld

import android.app.AlertDialog
import android.app.Dialog
import android.app.DialogFragment
import android.content.DialogInterface
import android.os.Bundle
import android.util.Log

class ConfirmDeleteDialogFragment : DialogFragment() {

    interface ConfirmDeleteListener {
        fun onDialogPositiveClick()
        fun onDialogNegativeClick()
    }

    val TAG = ConfirmDeleteDialogFragment::class.java.simpleName

    var listener: ConfirmDeleteListener? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(activity)
        builder.setMessage("Supprimer tout le contenu du téléphone ?")
                .setPositiveButton("Oh oui !", object: DialogInterface.OnClickListener {
                    override fun onClick(dialog: DialogInterface?, id: Int) {
                        Log.i(TAG, "Youpi ! on va tout casser")
                        listener?.onDialogPositiveClick()
                    }
                })
                .setNegativeButton("Euh... Non", DialogInterface.OnClickListener { dialog, id ->
                    Log.i(TAG, "Bon ben ce sera pour la prochaine fois")
                    dialog.dismiss()
                    listener?.onDialogNegativeClick()
                })

        return builder.create()
    }
}