package training.androidkotlin.helloworld

import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {

    private lateinit var swipeRefreshView: SwipeRefreshLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        swipeRefreshView = findViewById(R.id.swipe_refresh)
        swipeRefreshView.setOnRefreshListener {
            scheduleRefreshStop()
        }

        findViewById<Button>(R.id.refresh).setOnClickListener {
            swipeRefreshView.isRefreshing = true
            scheduleRefreshStop()
        }
    }

    private fun scheduleRefreshStop() {
        // stop swipe refresh animation 2 seconds later
        val handler = Handler()
        handler.postDelayed({ swipeRefreshView.isRefreshing = false }, 2000)
    }
}
