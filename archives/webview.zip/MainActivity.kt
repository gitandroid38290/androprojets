package training.androidkotlin.helloworld

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.KeyEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val webViewClient: WebViewClient = object: WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
            Log.i("MainActivity", "Loading URL=$url")

            val containsStudio = url?.contains("studio") ?: false

            if (containsStudio) {
                Toast.makeText(this@MainActivity, "Chargement Android Studio", Toast.LENGTH_SHORT)
                        .show()
            }
            return super.shouldOverrideUrlLoading(view, url)
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.web_view)
        webView.webViewClient = webViewClient

        // configure the webview
        val settings = webView.settings
        settings.javaScriptEnabled = true

        // loading url
        webView.loadUrl("https://developer.android.com")
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // handle previous page with back key
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }

        return super.onKeyDown(keyCode, event)
    }
}
