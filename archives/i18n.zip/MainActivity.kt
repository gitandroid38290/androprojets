package training.androidkotlin.helloworld

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val labelFlour = findViewById<TextView>(R.id.label_flour)
        labelFlour.text = getString(R.string.label_flour, 300)

        // plurals with numbers
        val eggCount = 2
        val labelEggs = findViewById<TextView>(R.id.label_eggs)
        labelEggs.text = resources.getQuantityString(R.plurals.number_of_eggs, eggCount, eggCount)
    }
}
