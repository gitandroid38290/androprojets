package training.androidkotlin.helloworld

import android.app.FragmentTransaction
import android.os.Bundle
import android.support.v7.app.AppCompatActivity

class MainActivity : AppCompatActivity(), RedFragment.RedFragmentListener {

    private lateinit var blueFragment: BlueFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        blueFragment = BlueFragment()

        // add red fragment
        val redFragment = RedFragment()
        redFragment.listener = this

        supportFragmentManager.beginTransaction()
                .replace(R.id.container, redFragment)
                .commit()

    }


    override fun onClick() {

        supportFragmentManager.beginTransaction()
                .replace(R.id.container, blueFragment)
                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                .addToBackStack(null)
                .commit()
    }

}
