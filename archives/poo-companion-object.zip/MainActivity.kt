package training.androidkotlin.helloworld

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

abstract class Vehicle(val wheelsCount: Int) {

    companion object Factory {
        fun createCar() : Car = Car(4)
        fun createMotorcycle() : Motorcycle = Motorcycle(2)
    }
}

class Car(wheelsCount: Int) : Vehicle(wheelsCount)

class Motorcycle(wheelsCount: Int) : Vehicle(wheelsCount)

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val car = Vehicle.createCar()
        val motorcycle = Vehicle.Factory.createMotorcycle()
    }
}
