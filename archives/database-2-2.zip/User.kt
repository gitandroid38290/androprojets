package training.androidkotlin.helloworld

data class User(val name: String,
                val age: Int,
                val email: String)
