package training.androidkotlin.helloworld

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    val TAG = MainActivity::class.java.simpleName

    companion object {
        var staticTextView: TextView? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.i(TAG, "onCreate")

        val textViewApp = TextView(applicationContext)
        textViewApp.textSize = 30f
        textViewApp.text = "Application Context"

        val textViewActivity = TextView(this)
        textViewActivity.textSize = 30f
        textViewActivity.text = "Activity Context"

        val layout: LinearLayout = findViewById(R.id.root)
        layout.addView(textViewApp)
        layout.addView(textViewActivity)

        // Boom! Memory leak
        if (staticTextView == null) {
            staticTextView = textViewActivity
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy")
    }
}
