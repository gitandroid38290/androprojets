package training.androidkotlin.helloworld

import android.app.Application
import android.util.Log

class App : Application() {

    val TAG = App::class.java.simpleName

    override fun onCreate() {
        super.onCreate()

        Log.i(TAG, "onCreate()")
    }
}