package training.androidkotlin.helloworld

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

const val VERSION: Int = 42
const val NAME = "Bob"

class MainActivity : AppCompatActivity() {

    companion object {
        const val TEST = "it works!"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val localVersion = VERSION
        val localTest = MainActivity.TEST
    }
}
