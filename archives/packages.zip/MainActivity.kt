package training.androidkotlin.helloworld

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.widget.ViewDragHelper


//import training.androidkotlin.helloworld.common.captainAge

import training.androidkotlin.helloworld.common.captainName
import training.androidkotlin.helloworld.common.describeCaptain
//import training.androidkotlin.helloworld.common.*

class MyClass<T>(val var1: T)

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // println("L'age du captitaine est ${captainAge}")
        println("Le nom du capitaine par défaut est ${captainName}")
        //captainAge = "Mike"

        describeCaptain()

    }
}
