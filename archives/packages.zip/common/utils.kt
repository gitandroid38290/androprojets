package training.androidkotlin.helloworld.common

private val captainAge = 5

public var captainName = "Jane"
    private set


fun describeCaptain() {
    captainName = "Bob"
    println("Le capitaine est ${captainName}, il a ${captainAge}")
}