package training.androidkotlin.helloworld

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.widget.Button

class MainActivity : AppCompatActivity() {

    val PERMISSION_CALL_PHONE = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        // needs ACCESS_NETWORK_STATE permission (normal permission)
        // normal permissions: https://developer.android.com/guide/topics/permissions/normal-permissions.html
        val networkInfo = connectivityManager.activeNetworkInfo
        val isConnected = networkInfo?.isConnectedOrConnecting ?: false

        Log.i("MainActivity", "Téléphone connecté à internet ? " + isConnected)


        findViewById<Button>(R.id.call_phone).setOnClickListener {
            // needs CALL_PHONE permission (dangerous permission)
            // dangerous permission: https://developer.android.com/guide/topics/permissions/requesting.html#normal-dangerous

            if (ContextCompat.checkSelfPermission(this,
                    android.Manifest.permission.CALL_PHONE)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        arrayOf(android.Manifest.permission.CALL_PHONE),
                        PERMISSION_CALL_PHONE)
            } else {
                callPhone()
            }

        }
    }

    @SuppressLint("MissingPermission")
    fun callPhone() {
        val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:12345"))
        startActivity(callIntent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when (requestCode) {
            PERMISSION_CALL_PHONE -> {
                if (grantResults.isNotEmpty()
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callPhone()
                }
            }
        }
    }
}
