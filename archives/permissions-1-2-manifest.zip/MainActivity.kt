package training.androidkotlin.helloworld

import android.os.Bundle
import android.os.Environment
import android.support.v7.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        writeDataToFile("test.txt", "Hello from Kotlin")
    }

    fun writeDataToFile(filename: String, data: String) {
        val file = File(Environment.getExternalStorageDirectory(), filename)

        FileOutputStream(file).use { fos ->
            fos.write(data.toByteArray())
            fos.flush()
        }
    }
}
