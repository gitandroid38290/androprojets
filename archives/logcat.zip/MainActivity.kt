package training.androidkotlin.helloworld

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.widget.ViewDragHelper
import android.util.Log

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.v(TAG, "Verbose message")
        Log.d(TAG, "Debug message")
        Log.i(TAG, "Info message")
        Log.w(TAG, "Warning message")
        Log.e(TAG, "Error message")
        Log.println(Log.ASSERT, TAG, "ASSERT")

        val test = TestLog()
        test.myFunc()
    }
}

class TestLog {
    private val TAG = TestLog::class.java.simpleName

    fun myFunc() {
        Log.i(TAG, "myFunc message")
    }
}
