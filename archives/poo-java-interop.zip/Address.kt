package training.androidkotlin.helloworld

data class Address(val city: String, val country: String)
